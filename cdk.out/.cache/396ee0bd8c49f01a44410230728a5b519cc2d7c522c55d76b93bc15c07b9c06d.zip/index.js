exports.handler = async (event = {}) => {
    return {
        body: 'Hello All, This is sample API',
        statusCode: 200,
    };
};